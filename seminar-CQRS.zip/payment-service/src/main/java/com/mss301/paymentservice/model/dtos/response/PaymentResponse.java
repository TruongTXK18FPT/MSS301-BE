package com.mss301.paymentservice.model.dtos.response;

import com.mss301.paymentservice.constant.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentResponse {
    private Long paymentId;
    private SubscriptionResponse subscription;
    private UserResponse user;
    private Long amount;
    private String orderInfo;
//    private String momoRequestId;
//    private String momoTransId;
    private String paymentUrl;
    private Status status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
